<?php
try {
  //connection au serveur
  $cnx = new PDO( "mysql:hosts=localhost;dbname=INFOS", "root", "beziers01" ) ;
  
  //sélection de la base de données:
 
  //récupération des valeurs des champs:
  //nom:
  $nom     = $_POST["nom"] ;
  //prenom:
  $prenom = $_POST["prenom"] ;
  //adresse:
  $adresse = $_POST["adresse"] ;
  //code postal:
  $cp        = $_POST["codePostal"] ;
  //numéro de téléphone:
  $tel       = $_POST["telephone"] ;
 
  //création de la requête SQL:
  $sql = "INSERT  INTO personnes (nom, prenom, adresse, cp, telephone)
            VALUES ( '$nom', '$prenom', '$adresse', '$cp', '$tel') " ;
    //exécution de la requête SQL:
    
  $requete = $cnx->prepare($sql)->execute();
    
    //affichage des résultats, pour savoir si l'insertion a marchée:
    if($requete)
    {
      echo("L'insertion a été correctement effectuée") ;
    }
    else
    {
      echo("L'insertion à échouée") ;
    }
      
  } catch (Exception $ex) {
      echo $ex->getMessage();
  }
 
?>
