<html>
  <head>
    <title>insertion de données en PHP :: partie 1</title>
  </head>
<body>
<form name="insertion" action="insertion2.php" method="POST">
  <table border="0" align="center" cellspacing="2" cellpadding="2">
    <tr align="center">
      <td>nom</td>
      <td><input type="text" name="nom"></td>
    </tr>
    <tr align="center">
      <td>prenom</td>
      <td><input type="text" name="prenom"></td>
    </tr>
    <tr align="center">
      <td>adresse</td>
      <td><input type="text" name="adresse"></td>
    </tr>
    <tr align="center">
      <td>code postal</td>
      <td><input type="text" name="codePostal"></td>
    </tr>
    <tr align="center">
      <td>numéro de téléphone</td>
      <td><input type="text" name="telephone"></td>
    </tr>
 
    <tr align="center">
      <td colspan="2"><input type="submit" value="insérer"></td>
    </tr>
  </table>
</form>
</body>
</html>