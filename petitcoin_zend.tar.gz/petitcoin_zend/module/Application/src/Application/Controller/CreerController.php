<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

class CreerController extends AbstractActionController
{
    public function indexAction()
    {

      session_start();
       try{

      $target_file1 = "";
      $target_file2 = "";
      $target_file3 = "";
$conar = new \PDO ("mysql:host=localhost;dbname=rendu","root","root");
      if(isset($_FILES["img1"])) {

      $target_file1= "/var/www/html/petitcoin_zend/public/upload/img/";
      $target_file1 .= md5(mt_rand() . time()) . "_" .basename($_FILES["img1"]['name']);
      move_uploaded_file($_FILES["img1"]["tmp_name"], $target_file1);

      }

      $conar = new \PDO ("mysql:host=localhost;dbname=rendu","root","root");
            if(isset($_FILES["img2"])) {

            $target_file2= "/var/www/html/petitcoin_zend/public/upload/img/";
            $target_file2 .= md5(mt_rand() . time()) . "_" .basename($_FILES["img2"]['name']);
            move_uploaded_file($_FILES["img2"]["tmp_name"], $target_file2);

            }

            $conar = new \PDO ("mysql:host=localhost;dbname=rendu","root","root");
                  if(isset($_FILES["img3"])) {

                  $target_file3= "/var/www/html/petitcoin_zend/public/upload/img/";
                  $target_file3 .= md5(mt_rand() . time()) . "_" .basename($_FILES["img3"]['name']);
                  move_uploaded_file($_FILES["img3"]["tmp_name"], $target_file3);

                  }


       $con = new \PDO ("mysql:host=localhost;dbname=rendu","root","root");
      if(isset($_POST['signup'])){
       $name = $_POST['name'];
      //  $email = $_POST['email'];
      //  $pass = $_POST['pass'];
      //  $date = $_POST['date'];
      //  $month = $_POST['month'];
      //  $year = $_POST['year'];
       $prix = $_POST['prix'];
       $intitule = $_POST['intitule'];
       $description = $_POST['description'];
       $type = $_POST['type'];
       $typean = $_POST['typean'];
      //  $date=$_POST['date'];

       $auteur=$_SESSION['name'];

       $theme=$_POST['theme'];
       $catego=$_POST['catego'];
      //  $sql="INSERT INTO BEZIERS_annonce_LPC date=".$date;





      $insert = $con->prepare("INSERT INTO BEZIERS_annonce_LPC (prix,intitule,description,type,typean,auteur,theme,catego,img1,img2,img3)
      values(:prix,:intitule,:description,:type,:typean,:auteur,:theme,:catego,:img1,:img2,:img3) ");
      $insert->bindParam(':prix',$prix);
      $insert->bindParam(':intitule',$intitule);
      $insert->bindParam(':description',$description);
      $insert->bindParam(':type',$type);
      $insert->bindParam(':typean',$typean);
      $insert->bindParam(':auteur',$auteur);
      $insert->bindParam(':catego',$catego);
      $insert->bindParam(':theme',$theme);
      $insert->bindParam(':img1',basename($target_file1));
      $insert->bindParam(':img2',basename($target_file2));
      $insert->bindParam(':img3',basename($target_file3));
      $insert->execute();


      }elseif(isset($_POST['signin'])){
       $email = $_POST['email'];
       $pass = $_POST['pass'];

       $select = $con->prepare("SELECT * FROM BEZIERS_users_LPC WHERE email='$email' and pass='$pass'");
       $select->setFetchMode(\PDO::FETCH_ASSOC);
       $select->execute();
       $data=$select->fetch();
       if($data['email']!=$email and $data['pass']!=$pass)
       {
        echo "invalid email or pass";
       }
       elseif($data['email']==$email and $data['pass']==$pass)
       {
       $_SESSION['email']=$data['email'];
          $_SESSION['name']=$data['name'];
  header("location:index");
       }
       }
      }
      catch(\PDOException $e)
      {
      echo "error".$e->getMessage();
      }
      $con = new \PDO ("mysql:host=localhost;dbname=rendu","root","root");
      $names = $_SESSION['name'];
      $reponse = $con->query("SELECT * FROM BEZIERS_users_LPC where name = '$names'");
              $valeur = $reponse->fetch();




              return new ViewModel(array('user' => $valeur));











        return new ViewModel();
    }


    public function profileAction()
    {
      session_start();
      if(empty($_SESSION['email']))
      {
       header("location:index");
      }


        return new ViewModel();
    }


    public function annoncesAction()
    {


        return new ViewModel();
    }




}
