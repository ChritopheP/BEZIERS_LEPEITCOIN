<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

class LoginController extends AbstractActionController
{
    public function indexAction()
    {
      $message = "";
      session_start();
      $_SESSION['connecte'] = false;
       try{
       $con = new \PDO ("mysql:host=localhost;dbname=rendu","root","root");
      if(isset($_POST['signup'])){
       $name = $_POST['name'];
       $email = $_POST['email'];
       $pass = $_POST['pass'];
       $tel = $_POST['tel'];
       $cpostal = $_POST['cpostal'];
       $Ville = $_POST['Ville'];
       $date = $_POST['date'];
       $month = $_POST['month'];
       $year = $_POST['year'];

       $mob = $_POST['mob'];
       $addr = $_POST['addr'];
       $insert = $con->prepare("INSERT INTO BEZIERS_users_LPC (name,email,pass,tel,cpostal,Ville,mob,addr,date,month,year)
       values(:name,:email,:pass,:tel,:cpostal,:Ville,:mob,:addr,:date,:month,:year) ");
      $insert->bindParam(':name',$name);
      $insert->bindParam(':email',$email);
      $insert->bindParam(':pass',$pass);
      $insert->bindParam(':tel',$tel);
      $insert->bindParam(':cpostal',$cpostal);
      $insert->bindParam(':Ville',$Ville);
      $insert->bindParam(':mob',$mob);
      $insert->bindParam(':addr',$addr);
      $insert->bindParam(':date',$date);
      $insert->bindParam(':month',$month);
      $insert->bindParam(':year',$year);
      $insert->execute();



      }elseif(isset($_POST['signin'])){
       $email = $_POST['email'];
       $pass = $_POST['pass'];

       $select = $con->prepare("SELECT * FROM BEZIERS_users_LPC WHERE email='$email' and pass='$pass'");
       $select->setFetchMode(\PDO::FETCH_ASSOC);
       $select->execute();
       $data=$select->fetch();
       if($data['email']!=$email or $data['pass']!=$pass)
       {
        $message = "invalid email or pass";
       }
       else
       {
       $_SESSION['email']=$data['email'];
          $_SESSION['name']=$data['name'];
          header("location:profile");
          $message = "connecté";
          $_SESSION['connecte'] = true;
            header('location:profile');
            exit();

       }
       }
      }
      catch(\PDOException $e)
      {
      echo "error".$e->getMessage();
      }

        return new ViewModel(array('message' => $message));
    }


    public function profileAction()
    {
      session_start();
      if(empty($_SESSION['email']))
      {
       header("location:index");
      }


        return new ViewModel();
    }







    public function logoutAction()
    {
      session_start();
      session_destroy();
      // header("location:logout");


      return new ViewModel();

    }

 }
