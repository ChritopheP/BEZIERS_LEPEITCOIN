<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

class modifiemoncompteController extends AbstractActionController
{
    public function indexAction()
    {

      session_start();


    return new ViewModel();

      }



      public function modif1Action()
      {

session_start();


      return new ViewModel();

        }

        public function modif2Action()
        {

session_start();


        return new ViewModel();

          }

          public function modif3Action()
          {

session_start();


          return new ViewModel();

            }

            public function modifan1Action()
            {


session_start();

            return new ViewModel();

              }



              public function modifan2Action()
              {
session_start();



              return new ViewModel();

                }



                public function modifan3Action()
                {

session_start();


                return new ViewModel();

                  }


                  public function supr1Action()
                  {


session_start();

                  return new ViewModel();

                    }



                    public function supr2Action()
                    {

session_start();


                    return new ViewModel();

                      }





}
